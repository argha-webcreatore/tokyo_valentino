https://tympanus.net/codrops/2019/11/05/creative-webgl-image-transitions/
https://github.com/akella/webGLImageTransitions
https://www.youtube.com/watch?v=HlCzCq46YTk&ab_channel=developedbyed