
    <footer>
        <div class="footer-top">
            <div class="container">
                <div class="row g-3">

                    <div class="col-md-3">
                        <a class="index.html" href="#">
                            <img src="assets/frontend/img/logo.png" alt="" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <h5 class="foo-title">Quick Links</h5>
                        <ul class="foo-quick-link">
                            <li><a href="#">Online Store</a></li>
                            <li><a href="#">Videos On Demand</a></li>
                            <li><a href="#">Special Events</a></li>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h5 class="foo-title">Store Locations</h5>
                        <ul class="foo-link">
                            <li><a href="#">Cheshire Bridge Rd., Atlanta</a></li>
                            <li><a href="#">Sandy Springs, Georgia</a></li>
                            <li><a href="#">Northside Dr., Atlanta</a></li>
                            <li><a href="#">East Cobb, Georgia</a></li>
                            <li><a href="#">Gwinnett, Georgia</a></li>
                            <li><a href="#">Marietta, Georgia</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h5 class="foo-title">Connect with Us</h5>
                        <ul class="foo-contact">
                            <li class="contact-item">
                                <a href="#">
                                    <i class="cont-icon fas fa-location-dot"></i>
                                    <span>1739 Cheshire Bridge Road,
                                    Atlanta, GA 30324</span>
                                </a>
                                
                            </li>
                            <li class="contact-item">
                                <a href="#">
                                    <i class="cont-icon fas fa-phone"></i>
                                    <span>404-875-9200</span>
                                </a>
                            </li>
                            <li class="contact-item">
                                <a href="#">
                                    <i class="cont-icon fas fa-envelope"></i>
                                    <span>sales@tokyovalentino.com</span>
                                </a>
                            </li>
                            <li class="contact-item">
                                <a href="#">
                                    <i class="cont-icon fas fa-envelope"></i>
                                    <span>info@tokyovalentino.com</span>
                                </a>
                            </li>
                        </ul>
                        <ul class="list-inline foo-social">
                            <li class="list-inline-item">
                                <a href="#">
                                    <i class="fab fa-facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#">                                    
                                    <i class="fab fa-yelp"></i>
                                </a>
                            </li>
                            
                        </ul>
                    </div>

                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p class="text-center mb-0">© Copyright 2022 Tokyo Valentino. All Rights Reserved</p>
        </div>
    </footer>